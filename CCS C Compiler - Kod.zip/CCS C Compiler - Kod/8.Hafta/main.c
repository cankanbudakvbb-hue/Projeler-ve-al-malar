#include <main.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>

void main(){
lcd_init();
basla:
output_low(PIN_B0);
output_high(PIN_B1);
output_low(PIN_B2);
   
   while(TRUE) {
      if(input(PIN_A0)==0){
      output_high(PIN_B0);
      output_low(PIN_B1);
      output_low(PIN_B2);
      delay_ms(250);
      }
      else if(input(PIN_A1)==0){
      output_low(PIN_B0);
      output_low(PIN_B1);
      output_high(PIN_B2);
      delay_ms(250);
      }
      else if(input(PIN_A2)==0){
      goto basla;
      delay_ms(250);
      }
   }
}

