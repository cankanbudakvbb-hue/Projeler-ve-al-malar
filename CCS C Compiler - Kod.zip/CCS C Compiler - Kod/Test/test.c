#include <test.h>
#include <lcd.c>
#include <math.h>
#include <stdio.h>
unsigned int x;
float v,adc;
void main(){
lcd_init();
setup_adc(adc_clock_internal);
setup_adc_ports(an0);
}
void loop(){

}
