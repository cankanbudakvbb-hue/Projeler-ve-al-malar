#include <for_dongu7.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>
int sn,dk,s;
void main(){
lcd_init();
for(s=0;s<24;s++){
for(dk=0;dk<60;dk++){
for(sn=0;sn<60;sn++){
printf(lcd_putc,"\f%d: %d %d"s,dk,sn);
delay_ms(1000);
}}}}
