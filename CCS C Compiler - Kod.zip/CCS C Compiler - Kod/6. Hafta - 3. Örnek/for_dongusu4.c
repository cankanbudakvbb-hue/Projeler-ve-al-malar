#include <for_dongusu4.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>
int x = 0; 
void main(){ 
   lcd_init();
   while(x<6){
   x=x+1;
   printf(lcd_putc,"%d\t",x);
   delay_ms(500);
   }
   printf(lcd_putc,"\nSon");
}
