#include <main.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>
float x,y,toplam,carpim,bolum;
char islem;
void main(){
   lcd_init(); 
   x=15; y=16;
   islem ='!';
   switch(islem){
   case '+':
   toplam=x+y;
   printf(lcd_putc,"\fX=%fY=%f\nToplam=%f",x,y,toplam);
   break;
   
   case '-':
   toplam=x+y;
   printf(lcd_putc,"\fX=%fY=%f\nFark=%f",x,y,toplam);
   break;
   
   case '/':
   toplam=x+y;
   printf(lcd_putc,"\fX=%fY=%f\nBolum=%f",x,y,toplam);
   break;
   
   case '*':
   toplam=x+y;
   printf(lcd_putc,"\fX=%fY=%f\nCarpim=%f",x,y,toplam);
   break;
   
   default:
   printf(lcd_putc,"Yanlis karakter.");
   }
}  
