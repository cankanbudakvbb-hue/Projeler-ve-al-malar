#include <Test_20Mhz.h>
#include <lcd.c>
#include <math.h>
#include <stdio.h>
unsigned int analog;
float frekans,yuzde,v;
void main(){
lcd_init();
setup_adc(adc_clock_internal);
setup_adc_ports(an0);
setup_timer_2(t2_div_by_16,255,1);
setup_ccp1(ccp_pwm);
while(true){
set_adc_channel(0);
analog=read_adc();
set_pwm1_duty(analog);
frekans=(float)(20000)/(16*4*255);
yuzde=(float)(100*analog)/255;
v=(float)(analog*5)/255;
printf(lcd_putc,"\fF:%f Y:%f\nV:%f",frekans,yuzde,v);
delay_ms(250);
}
}
void loop(){

}


