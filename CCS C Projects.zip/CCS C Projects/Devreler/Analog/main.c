#include <main.h>
#include <lcd.c>
#include <math.h>
#include <stdio.h>
unsigned int analog;
float v,adc;
void main(){
lcd_init();
setup_adc(adc_clock_internal);
setup_adc_ports(an0);
while(true){
set_adc_channel(0);
analog=read_adc();
printf(lcd_putc,"\fADC:%u",analog);
lcd_gotoxy(1,2);
adc=analog;
v=(adc*5)/255;
printf(lcd_putc,"V:%f",v);
delay_ms(250);
}
if(analog>0){
output_bit(pin_b7,1);
}
if(analog>32){
output_bit(pin_b6,1);
}
if(analog>64){
output_bit(pin_b5,1);
}
if(analog>96){
output_bit(pin_b4,1);
}
if(analog>128){
output_bit(pin_b3,1);
}
if(analog>160){
output_bit(pin_b2,1);
}
if(analog>192){
output_bit(pin_b1,1);
}
if(analog>224){
output_bit(pin_b0,1);
}

}
void loop(){

}
