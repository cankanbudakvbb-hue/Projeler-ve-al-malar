#include <for_dongusu5.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>

int x;
void main()
{
   lcd_init();
   while(x<6)
   {
      x=x+1;
      printf(lcd_putc,"%d\t",x); // Aral�kl� yazd�r.
      delay_ms(500); // 0,5 sn bekle.
   }
   printf(lcd_putc,"\nSon"); // 2. Sat�ra yazd�r.
}
