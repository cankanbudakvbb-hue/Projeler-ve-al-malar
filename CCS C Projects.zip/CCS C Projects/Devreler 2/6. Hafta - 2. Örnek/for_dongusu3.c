#include <for_dongusu3.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>
int sayi; // Tam say� de�i�ken
void main(){ // Ana program
lcd_init(); // LCD �al��t�rma
for(sayi=0;sayi<=10;sayi++){ // Say�n�n de�erini 10 kadar 1 artt�r�r.
if((sayi%2)==0){ // 2 b�l�m�nden kalan 0 ise
printf(lcd_putc,"\fCift Sayi:%d"sayi); // Ekrana yazd�r.
}
else if((sayi%2)==1){ // 2 ile b�l�m�nden kalan 1 ise
printf(lcd_putc,"\nTek Sayi:%d",sayi); // Ekrana yazd�r.
}
delay_ms(500);
}
}

// \n alt sat�ra ge�irme.
// \f Sayfa sonu demek.
