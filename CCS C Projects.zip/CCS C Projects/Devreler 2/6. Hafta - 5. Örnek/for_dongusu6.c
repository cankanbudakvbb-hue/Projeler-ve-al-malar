#include <for_dongusu6.h>
#include <LCD.C>
#include <math.h>
#include <stdio.h>

int i;
void main()
{
   lcd_init();
   while(TRUE)
   {
      for(i=1;i<=16;i++){
      printf(lcd_putc,"\f"); // Ekran� temizle
      lcd_gotoxy(i,1);
      printf(lcd_putc,"Cankan"); // Sa�dan sola ad�n kaymas�n� sa�lar.
      lcd_gotoxy(16-i,2); // Sa�dan sola soyad�n�n kaymas�n� sa�l�yor ama \f kodu olmad��� i�in �al���yor lcd_putc'lerde.
      printf(lcd_putc,"Budak");
      delay_ms(250);
      }
   }
}

//\f Format (sil), sat�r� temizler atlama vs. olmamas� i�in.
